
function fb(params,n) {
    document.getElementById(params).onfocus= function () {
        document.getElementById(params).style.boxShadow = "0px 0px "+n+"px rgb(89, 220, 243)";
    }
    document.getElementById(params).onblur= function () {
        document.getElementById(params).style.boxShadow = "none";
    }
}

fb("html-is-parent",15);
fb("content_pc_span1", 10);
fb("content_pc_span2",10)
fb("username",10);
fb("password", 10);
fb("b2", 10);
fb("ph_a", 10);
fb("a1", 10);
fb("a2", 10);
fb("i1", 10);
fb("i2", 10);
fb("d2a1", 10);
fb("d2a2", 10);
fb("d2a3", 10);
fb("d2a4", 10);
fb("d2a5", 10);
fb("d2a6", 10);
fb("d2a7", 10);
fb("d2a8", 10);
document.getElementById("b1").onmouseover = function () {
    document.getElementById("b2").style.display = "block";
}
document.getElementById("b2").onmouseout=function () {
    document.getElementById("b2").style.display = "none";
}
document.getElementById("d3").onmouseover = function () {
    document.getElementById("d3").getElementsByTagName("img")[0].setAttribute('src', "zy/img/g2.png");
    document.getElementById("d4").style.display = "block";
}
document.getElementById("d3").onmouseout = function () {
    document.getElementById("d3").getElementsByTagName("img")[0].setAttribute('src', "zy/img/g.png");
    document.getElementById("d4").style.display = "none";
}
document.getElementById("b2").onclick = function () {
    var name = document.getElementById("username").value;
    var paswd = document.getElementById("password").value;
    if (name == ""){
        document.getElementById("username").focus();
    }else if (paswd == ""){
        document.getElementById("password").focus();
    }
    if(name != ""&&paswd != "")
        api_name_paswd(name, paswd);
}